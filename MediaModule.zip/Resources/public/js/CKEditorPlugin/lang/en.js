CKEDITOR.plugins.setLang('cmfcmfmediamodule', 'en', {
    title: 'Insert media object',
    alt: 'Insert media object'
});
