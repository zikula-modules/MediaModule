CKEDITOR.plugins.setLang('cmfcmfmediamodule', 'de', {
    title : 'Medienobjekt einfügen',
    alt: 'Medienobjekt einfügen'
});
