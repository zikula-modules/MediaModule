(function ($) {
    $(function () {
        $('.cmfcmfmedia-display-lightgallery').lightGallery({
            thumbnail: false,
            subHtmlSelectorRelative: true
        });
    })
})(jQuery);
