(function ($) {
    $(function() {
        $('.cmfcmfmedia-plaintext-highlight').each(function(i, block) {
            hljs.highlightBlock(block);
        });
    });
})(jQuery);
