These are all [Google Fonts](https://www.google.com/fonts). This makes it possible to not only 
download the `*.ttf` files but also embed the fonts at the watermark edit form page.
