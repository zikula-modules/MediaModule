<?php

/*
 * This file is part of the MediaModule for Zikula.
 *
 * (c) Christian Flach <hi@christianflach.de>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Cmfcmf\Module\MediaModule\CollectionTemplate;

/**
 * Provides a list of all collection templates with some convenience methods.
 */
class TemplateCollection
{
    /**
     * @var TemplateInterface[]
     */
    private $templates;

    public function __construct()
    {
        $this->templates = [];
    }

    /**
     * Adds a collection template to the template list.
     *
     * @param TemplateInterface $template
     */
    public function addCollectionTemplate(TemplateInterface $template)
    {
        $this->templates[$template->getName()] = $template;
    }

    /**
     * Returns the list of collection templates indexed by template name.
     *
     * @return array|TemplateInterface[]
     */
    public function getCollectionTemplates()
    {
        return $this->templates;
    }

    /**
     * Returns a list of template titles indexed by template name.
     *
     * @return array|string[]
     */
    public function getCollectionTemplateTitles()
    {
        return array_map(function (TemplateInterface $template) {
            return $template->getTitle();
        }, $this->templates);
    }

    /**
     * Returns the specified collection template.
     *
     * @param string $template The template name.
     *
     * @return TemplateInterface
     */
    public function getCollectionTemplate($template)
    {
        if (!$this->hasTemplate($template)) {
            throw new \DomainException();
        }

        return $this->templates[$template];
    }

    /**
     * Checks whether or not the specified collection template exists.
     *
     * @param string $template The template name.
     *
     * @return bool
     */
    public function hasTemplate($template)
    {
        return isset($this->templates[$template]);
    }
}
